// main.go
package main

import "fmt"

func main() {
  fmt.Println("Mi cliente de Github")
}
