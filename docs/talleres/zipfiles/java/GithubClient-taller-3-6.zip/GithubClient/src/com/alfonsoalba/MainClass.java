package com.alfonsoalba;

import org.json.JSONArray;
import org.json.JSONObject;

public class MainClass {

	public static void main(String[] args) throws Exception {
		try {			
	        String token = System.getenv().get("GITHUB_PERSONAL_ACCESS_TOKEN");
			Client client = new Client(token);
	        JSONArray json = client.getIssues("gradle/gradle");
	        printIssues(json);
		} catch(Exception e) {
			System.out.println(e.getMessage());
			throw e;
		}
	}
	
	private static void printIssues(JSONArray json) {
        for (int i = 0; i < json.length(); i++) {
            JSONObject jsonObject = json.getJSONObject(i);
            String title = jsonObject.getString("title");
            System.out.println("Title: " + title);
        }
	}
}