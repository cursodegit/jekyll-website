package com.alfonsoalba;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import org.json.JSONArray;
import org.json.JSONException;

public class Client {
	private HttpClient client;
	private String token;

	public Client(String token) {
		this.client = HttpClient.newHttpClient();
		this.token = token;
	}

	public JSONArray getIssues(String repo) throws Exception {
		String url = "https://api.github.com/repos/" + repo + "/issues";
		HttpRequest request = HttpRequest.newBuilder(URI.create(url))
				.header("Accept", "application/vnd.github+json")
				.header("Content-Type", "application/vnd.github.raw+json")
				.header("Authorization", "Bearer " + token)
				.header("X-GitHub-Api-Version", "2022-11-28")
				.build();

		HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

		return getJSONFromResponse(response);
	}

	private JSONArray getJSONFromResponse(HttpResponse<String> response) throws JSONException {
		try {
			return new JSONArray(response.body());
		} catch (JSONException e) {
			e.printStackTrace();
			throw e;
		}
	}
}