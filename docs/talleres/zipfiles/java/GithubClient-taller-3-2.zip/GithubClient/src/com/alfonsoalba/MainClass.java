package com.alfonsoalba;

public class MainClass {

	public static void main(String[] args) {
		System.out.print("Cliente de Github");
	}

}
