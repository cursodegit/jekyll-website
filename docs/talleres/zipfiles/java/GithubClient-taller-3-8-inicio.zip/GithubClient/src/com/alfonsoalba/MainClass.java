package com.alfonsoalba;

import org.json.JSONArray;

public class MainClass {

	public static void main(String[] args) throws Exception {
		try {			
			String token = System.getenv().get("GITHUB_PERSONAL_ACCESS_TOKEN");
			Client client = new Client(token);
			JSONArray json = client.getIssues("gradle/gradle");
			IssueFormatter formatter = new IssueFormatter();
			System.out.print(formatter.asString(json));
		} catch(InvalidTokenException e) {
			System.out.println(e.getMessage());
			System.exit(1);
		} catch(Exception e) {
			System.out.println(e.getMessage());
			throw e;
		}
	}
}