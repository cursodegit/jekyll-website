package com.alfonsoalba;

public class Colors {
	public static final String ANSI_RESET = "\u001B[0m";
	public static final String ANSI_RED = "\u001B[31m";
	public static final String ANSI_GREEN = "\u001B[32m";
	public static final String ANSI_BLUE = "\u001B[34m";
	public static final String ANSI_GRAY = "\u001B[37m";
	
	public static String red(String text) {
		return Colors.ANSI_RED + text + Colors.ANSI_RESET;
	}

	public static String green(String text) {
		return Colors.ANSI_GREEN + text + Colors.ANSI_RESET;
	}

	public static String blue(String text) {
		return Colors.ANSI_BLUE + text + Colors.ANSI_RESET;
	}
	
	public static String gray(String text) {
		return Colors.ANSI_GRAY + text + Colors.ANSI_RESET;
	}
}
