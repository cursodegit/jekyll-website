package com.alfonsoalba;

import org.json.JSONArray;
import org.json.JSONObject;

public class IssueFormatter {
	public String asString(JSONArray json) {
		String result = new String();
		
		for (int i = 0; i < json.length(); i++) {
			JSONObject jsonObject = json.getJSONObject(i);
			String title = jsonObject.getString("title");
			String state = jsonObject.getString("state");
			String url = jsonObject.getString("url");
			
			JSONObject userObject = jsonObject.getJSONObject("user");
			String user = userObject.getString("login");


			System.out.println(Colors.blue("[" + user + "]") + " - (" + state + ") - " + title);
			System.out.println("\t" + Colors.gray(url));
		}
		
		return result;
	}
}
