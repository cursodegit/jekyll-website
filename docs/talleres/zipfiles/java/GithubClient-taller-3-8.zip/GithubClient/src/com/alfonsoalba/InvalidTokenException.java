package com.alfonsoalba;

public class InvalidTokenException extends Exception {
	public InvalidTokenException(String errorMessage) {
		super(errorMessage);
	}
}