package main

// GitHubUser represents a GitHub user
type GitHubUser struct {
	Login string `json:"login"`
	Name  string `json:"name"`
	ID    int    `json:"id"`
}

// GitHubPullRequest represents a GitHub pull request
type GitHubPullRequest struct {
	Number  int        `json:"number"`
	Title   string     `json:"title"`
	HTMLURL string     `json:"html_url"`
	User    GitHubUser `json:"user"`
}
