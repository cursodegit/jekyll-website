module aalbagarcia/github-client

go 1.25.5
