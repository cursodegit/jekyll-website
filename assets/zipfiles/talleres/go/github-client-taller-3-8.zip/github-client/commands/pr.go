package commands

import (
	"fmt"
	"strings"

	"github.com/fatih/color"
	"github.com/spf13/cobra"
)

// PrCmd is the pull request command group
var PrCmd = &cobra.Command{
	Use:   "pr",
	Short: "Manage pull requests",
	Long:  `Commands for interacting with pull requests`,
}

// PrListCmd lists open pull requests for a repository
var PrListCmd = &cobra.Command{
	Use:   "list",
	Short: "List pull requests",
	Long:  `List open pull requests for a repository`,
	RunE: func(cmd *cobra.Command, args []string) error {
		// Load and validate token using shared helpers
		token, err := LoadToken()
		if err != nil {
			return err
		}

		// Create client
		ghClient, err := NewGitHubClient(token)
		if err != nil {
			return err
		}

		// Get repo from root command flag
		repo, err := cmd.Root().Flags().GetString("repo")
		if err != nil || repo == "" {
			return fmt.Errorf("-r flag is required (format: owner/repo)")
		}

		// Parse owner/repo
		parts := strings.Split(repo, "/")
		if len(parts) != 2 {
			return fmt.Errorf("invalid repo format: use owner/repo")
		}
		owner, repoName := parts[0], parts[1]

		// Get pull requests
		prs, err := ghClient.GetPRs(owner, repoName)
		if err != nil {
			return err
		}

		// Display pull requests
		if len(prs) == 0 {
			fmt.Println("No open pull requests found")
			return nil
		}

		for _, pr := range prs {
			color.Cyan("#%d", pr.Number)
			color.White(" - %s", pr.Title)
			fmt.Printf("  ")
			color.Yellow("Author: %s", pr.User.Login)
			fmt.Printf("  ")
			color.Black("URL: %s", pr.HTMLURL)
			fmt.Println()
		}

		return nil
	},
}
