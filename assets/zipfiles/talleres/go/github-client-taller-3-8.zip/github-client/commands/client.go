package commands

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"time"
)

// GitHubUser represents a GitHub user
type GitHubUser struct {
	Login string `json:"login"`
	Name  string `json:"name"`
	ID    int    `json:"id"`
}

// GitHubPullRequest represents a GitHub pull request
type GitHubPullRequest struct {
	Number  int        `json:"number"`
	Title   string     `json:"title"`
	HTMLURL string     `json:"html_url"`
	User    GitHubUser `json:"user"`
}

// GitHubClient encapsulates GitHub API interactions.
type GitHubClient struct {
	token string
}

// NewGitHubClient validates the token and returns a new client instance.
func NewGitHubClient(token string) (*GitHubClient, error) {
	token = strings.TrimSpace(token)
	if token == "" {
		return nil, fmt.Errorf("token cannot be empty")
	}
	return &GitHubClient{token: token}, nil
}

// formatGitHubError standardizes GitHub API error messages.
func (gc *GitHubClient) formatGitHubError(statusCode int, body []byte) error {
	return fmt.Errorf("GitHub API error (status %d): %s", statusCode, string(body))
}

// makeGitHubRequest executes an authenticated HTTP request to the GitHub API.
func (gc *GitHubClient) makeGitHubRequest(method, url string) ([]byte, error) {
	// Create HTTP client with timeout
	client := &http.Client{
		Timeout: 10 * time.Second,
	}

	// Create context with timeout
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	// Build request
	req, err := http.NewRequestWithContext(ctx, method, url, nil)
	if err != nil {
		return nil, fmt.Errorf("failed to create request: %w", err)
	}

	// Add authentication headers
	req.Header.Set("Authorization", "Bearer "+gc.token)
	req.Header.Set("Accept", "application/vnd.github+json")
	req.Header.Set("X-GitHub-Api-Version", "2022-11-28")

	// Execute request
	resp, err := client.Do(req)
	if err != nil {
		return nil, fmt.Errorf("request failed: %w", err)
	}
	defer resp.Body.Close()

	// Read response body
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, fmt.Errorf("failed to read response: %w", err)
	}

	// Check response status
	if resp.StatusCode != http.StatusOK {
		return nil, gc.formatGitHubError(resp.StatusCode, body)
	}

	return body, nil
}

// GetUser retrieves information about the authenticated GitHub user.
func (gc *GitHubClient) GetUser() (*GitHubUser, error) {
	url := "https://api.github.com/user"
	body, err := gc.makeGitHubRequest(http.MethodGet, url)
	if err != nil {
		return nil, err
	}

	var user GitHubUser
	if err := json.Unmarshal(body, &user); err != nil {
		return nil, fmt.Errorf("failed to decode user response: %w", err)
	}

	return &user, nil
}

// GetPRs retrieves open pull requests for a repository.
func (gc *GitHubClient) GetPRs(owner, repo string) ([]*GitHubPullRequest, error) {
	url := fmt.Sprintf("https://api.github.com/repos/%s/%s/pulls?state=open", owner, repo)
	body, err := gc.makeGitHubRequest(http.MethodGet, url)
	if err != nil {
		return nil, err
	}

	var prs []*GitHubPullRequest
	if err := json.Unmarshal(body, &prs); err != nil {
		return nil, fmt.Errorf("failed to decode pull requests response: %w", err)
	}

	return prs, nil
}

// LoadToken retrieves the token from environment or the config file.
func LoadToken() (string, error) {
	token := os.Getenv("GHC_TOKEN")
	if token == "" {
		homeDir, err := os.UserHomeDir()
		if err != nil {
			return "", fmt.Errorf("failed to get home directory: %w", err)
		}

		tokenPath := filepath.Join(homeDir, ".config", "github-client", "token")
		tokenBytes, err := os.ReadFile(tokenPath)
		if err != nil {
			if os.IsNotExist(err) {
				return "", fmt.Errorf("not authenticated: set GHC_TOKEN environment variable or run 'github-client auth login' first")
			}
			return "", fmt.Errorf("failed to read token: %w", err)
		}

		token = string(tokenBytes)
	}

	token = strings.TrimSpace(token)
	if token == "" {
		return "", fmt.Errorf("no authentication token found: set GHC_TOKEN environment variable or run 'github-client auth login' first")
	}

	return token, nil
}
