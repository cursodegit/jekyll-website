package commands

import (
	"github.com/spf13/cobra"
)

// RootCmd is the root command for the GitHub client
var RootCmd = &cobra.Command{
	Use:   "github-client",
	Short: "A GitHub CLI client",
	Long:  `github-client is a command-line interface for interacting with GitHub's REST API`,
}

// init sets up the command hierarchy and flags
func init() {
	// Build command hierarchy
	RootCmd.AddCommand(AuthCmd)
	AuthCmd.AddCommand(AuthLoginCmd)
	AuthCmd.AddCommand(AuthStatusCmd)

	RootCmd.AddCommand(PrCmd)
	PrCmd.AddCommand(PrListCmd)

	// Add flags
	RootCmd.PersistentFlags().StringP("repo", "r", "", "Repository in owner/repo format (e.g., golang/go)")
}
